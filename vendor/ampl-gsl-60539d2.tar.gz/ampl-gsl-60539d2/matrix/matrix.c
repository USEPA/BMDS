#include <config.h>
#include <gsl/gsl_errno.h>
#include <gsl/gsl_vector.h>

/* Compile all the inline matrix functions */

#define COMPILE_INLINE_STATIC
#include "build.h"
#include <gsl/gsl_matrix.h>

