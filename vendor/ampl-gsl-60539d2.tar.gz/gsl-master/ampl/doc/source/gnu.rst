GNU documentation and licenses
==============================

.. toctree::
   :maxdepth: 1

   freedoc
   gpl
   fdl
