No Warranty
-----------

The software described in this manual has no `warranty`:index:, it is
provided "as is". It is your responsibility to validate the behavior of
the routines and their accuracy using the source code provided, or to
purchase support and warranties from commercial redistributors.
Consult the GNU General Public license for further details
(see :ref:`gpl`).

