Introduction
============

.. toctree::
   :maxdepth: 2

   front-matter
   no-warranty
   accuracy
