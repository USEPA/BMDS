# Summary of recent updates to AMPL GSL bindings

## 20211111
Added support for gsl_sort function, now usable in session using NL solvers linked with ASL date >= 20211109.
## 20211014
Added statistics functions.
## 20211007
Beginning changelog. Linking against GSL 2.7.