## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----load_data, echo=TRUE-----------------------------------------------------
library(readxl)
dich_data           <- matrix(0,nrow=5,ncol=3)
colnames(dich_data) <- c("Dose","N","Incidence")
dich_data[,1] <- c(0,50,100,200,400)
dich_data[,2] <- c(20,20,20,20,20)
dich_data[,3] <- c(0,1,2,10,19)

## ----run_laplace_weibul-------------------------------------------------------
library(ToxicR)
library(ggplot2)
weibull_fit <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                      dich_data[,"N"],model_type="weibull")

## ----run_laplace_weibul2------------------------------------------------------
weibull_fit$bmd

## ----run_laplace_weibul3------------------------------------------------------
# Model Parameters
weibull_fit$parameters
# Covariance estimate on those parameters
weibull_fit$covariance
# The prior used
weibull_fit$prior

## ----run_laplace_weibul4------------------------------------------------------
# Model Parameters
logit_g = weibull_fit$parameters[1]
1/(1+exp(-logit_g))

## ----run_laplace_weibul6, fig.height = 5, fig.width = 6-----------------------
library(ggplot2) # This is needed to make changes
# Plot immediately
plot(weibull_fit)
# Save fit and modify
ggplot_fit <- plot(weibull_fit)
# Transform the x axis
ggplot_fit + scale_x_continuous(trans = "pseudo_log")
# Change labels
ggplot_fit + xlab("log(Dose) mg/kg/day") + ylab("Tumor Probability") + 
             scale_x_continuous(trans = "pseudo_log") + ggtitle("Weibull Fit") + theme_classic()


## ----run_laplace_weibul7, fig.height = 5, fig.width = 6-----------------------

# Laplace Explicitly Specified
weibull_fit_MAP <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                      dich_data[,"N"],model_type="weibull",fit_type="laplace")
# Maximum Likelihood Estimation
weibull_fit_MLE <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                      dich_data[,"N"],model_type="weibull",fit_type="mle")
# MCMC Estimation
weibull_fit_MCMC <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                      dich_data[,"N"],model_type="weibull",fit_type="mcmc")
library(ggpubr)
figure <- ggarrange(plot(weibull_fit_MAP)+ggtitle(""), plot(weibull_fit_MLE)+ggtitle(""), 
                    plot(weibull_fit_MCMC)+ggtitle(""),
                    labels = c("MAP", "MLE", "MCMC"),
                    ncol = 2, nrow = 2)
figure

## ----run_laplace_weibul8, fig.height = 5, fig.width = 6-----------------------

# Laplace Explicitly Specified
weibull_fit_MCMC_1 <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                      dich_data[,"N"],model_type="weibull",fit_type="mcmc",samples = 75000)
# Maximum Likelihood Estimation
weibull_fit_MCMC_2<- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                      dich_data[,"N"],model_type="weibull",fit_type="mcmc", BMR=0.05,samples = 7500)
# MCMC Estimation
weibull_fit_MCMC_3 <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                      dich_data[,"N"],model_type="weibull",fit_type="mcmc", BMR =0.01,samples = 7500)

fig_1 <- plot(weibull_fit_MCMC_1) + ggtitle("") + scale_x_continuous(trans="pseudo_log")
fig_2 <- plot(weibull_fit_MCMC_2) + ggtitle("") + scale_x_continuous(trans="pseudo_log")
fig_3 <- plot(weibull_fit_MCMC_3) + ggtitle("") + scale_x_continuous(trans="pseudo_log")
figure <- ggarrange(fig_1, fig_2, fig_3, 
                    labels = c("BMR=0.1", "BMR=0.05", "BMR=0.01"),
                    ncol = 2, nrow = 2)
figure

## ----run_laplace_weibul9------------------------------------------------------

# Laplace Explicitly Specified
prior <- create_prior_list(normprior(0,10,-100,100),
                           lnormprior(0,1,0,100),
                           lnormprior(0,1,0,100));

PR1    <- create_dichotomous_prior(prior,"weibull")

prior <- create_prior_list(normprior(0,10,-100,100),
                           lnormprior(0,0.1,0,100),
                           lnormprior(0,0.1,0,100));

PR2    <- create_dichotomous_prior(prior,"weibull")

PR1
PR2 

weibull_fit_prior1 <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                            dich_data[,"N"],model_type="weibull",fit_type="mcmc", 
                                            BMR=0.05,samples = 75000,prior=PR1)
weibull_fit_prior2 <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                            dich_data[,"N"],model_type="weibull",fit_type="mcmc", 
                                            BMR=0.05,samples = 75000,prior=PR2)

## ----run_laplace_weibul10, fig.height = 5, fig.width = 6----------------------
library(ggpubr)
figure <- ggarrange(plot(weibull_fit_prior1)+ggtitle(""), 
                    plot(weibull_fit_prior2)+ggtitle(""),
                    plot(weibull_fit_MLE)+ggtitle(""),
                    labels = c("Prior-1", "Prior-2","MLE"),
                    ncol = 2, nrow = 2)
figure 

## ----run_laplace_weibul11-----------------------------------------------------
library(ggpubr)
#Compare the BMDs
rbind(weibull_fit_prior1$bmd,weibull_fit_prior2$bmd)
#Extract the BMD CDF and remove possible infinities
#that may occur because of asymptotes etc.
#Note ecdf() is the emperical CDF function in R
temp <- ecdf(weibull_fit_prior1$mcmc_result$BMD_samples)
           
plot(temp,col=1,main="BMD prior comparison",xlab="BMD mg/kg/day",xlim=c(0,200),lwd=2)

temp <- ecdf(weibull_fit_prior2$mcmc_result$BMD_samples)
lines(temp,col=2,lwd=2)
## The default MCMC fit

temp <- ecdf(weibull_fit_MCMC$mcmc_result$BMD_samples)
lines(temp,col=3,lwd=2)

#For the MLE comparison
#The information is in the MLE/MAP objects object, though it is 
# a little different.
library(tidyverse)
temp <- as.data.frame(weibull_fit_MLE$bmd_dist)
names(temp) <- c("BMD","PROB")
temp <- temp %>% filter(!is.infinite(BMD))
lines(temp$BMD,temp$PROB,col=4,lwd=2)

## ----run_m_models, fig.height = 5, fig.width = 6------------------------------
qlinear_fit <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                      dich_data[,"N"],model_type="qlinear" )
gamma_fit <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                      dich_data[,"N"],model_type="gamma" )
hill_fit <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                      dich_data[,"N"],model_type="hill" )
lprobit_fit <- single_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                      dich_data[,"N"],model_type="log-probit" )

library(ggpubr)
figure <- ggarrange(plot(qlinear_fit)+ggtitle(""), 
                    plot(gamma_fit)+ggtitle(""),
                    plot(hill_fit)+ggtitle(""),
                    plot(lprobit_fit)+ggtitle(""),
                    labels = c("Quantal Linear", "Gamma","Hill","Log-Probit"),
                    ncol = 2, nrow = 2)
figure

## ----MA1, fig.height = 5, fig.width = 6---------------------------------------
ma_fit  <- ma_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                  dich_data[,"N"] )
plot(ma_fit)

ma_fit_mcmc  <- ma_dichotomous_fit(dich_data[,"Dose"],dich_data[,"Incidence"],
                                  dich_data[,"N"],fit_type='mcmc' )
plot(ma_fit_mcmc)

## ----MA2, fig.height = 5, fig.width = 6---------------------------------------
library(ggplot2)
cleveland_plot(ma_fit)+ggtitle("Cleveland Plot MA-Laplace")

MAdensity_plot(ma_fit_mcmc)+ggtitle("Density Plot MCMC")

